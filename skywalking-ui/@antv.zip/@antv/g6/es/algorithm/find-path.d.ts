import { IGraph } from '../interface/graph';
import { INode } from '../interface/item';
export declare const findShortestPath: (graph: IGraph, start: INode | string, end: INode | string, directed?: boolean, weightPropertyName?: string) => {
    length: any;
    path: any;
};
export declare const findAllPath: (graph: IGraph, start: INode | string, end: INode | string, directed?: boolean) => any[];
