import { IGraph } from '../interface/graph';
declare const dijkstra: (graph: IGraph, source: string, directed?: boolean, weightPropertyName?: string) => {
    length: {};
    path: {};
};
export default dijkstra;
