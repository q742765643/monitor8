/**
 * 并查集 Disjoint set to support quick union
 */
export default class UnionFind {
    count: number;
    parent: {};
    constructor(items: (number | string)[]);
    find(item: any): any;
    union(a: any, b: any): void;
    connected(a: any, b: any): boolean;
}
