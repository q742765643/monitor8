import { IGraph } from '../interface/graph';
declare const degree: (graph: IGraph) => {};
export default degree;
