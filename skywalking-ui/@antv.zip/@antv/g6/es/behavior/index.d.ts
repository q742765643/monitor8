import Behavior from './behavior';
export default Behavior;
