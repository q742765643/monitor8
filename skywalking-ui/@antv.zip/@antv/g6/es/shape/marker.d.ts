declare const _default: {
    collapse: (x: any, y: any, r: any) => any[][];
    expand: (x: any, y: any, r: any) => any[][];
    upTriangle: (x: any, y: any, r: any) => any[][];
    downTriangle: (x: any, y: any, r: any) => any[][];
};
export default _default;
