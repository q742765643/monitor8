/**
 * @fileOverview 从xml建立自定义Node，包含update
 * @author xuzhi.mxz@antfin.com
 */
/**
 * 内部用于最终实际渲染的结构
 */
interface NodeInstructure {
    type: string;
    attrs: {
        [key: string]: any;
    };
    children: NodeInstructure[];
    bbox: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
}
/**
 * 简单的一个{{}}模板渲染，不包含任何复杂语法
 * @param xml
 */
export declare const xmlDataRenderer: (xml: string) => (data: any) => string;
/**
 * 解析XML，并转化为相应的JSON结构
 * @param xml xml解析后的节点
 */
export declare function parseXML(xml: HTMLElement, cfg: any): {
    [key: string]: any;
} & NodeInstructure;
/**
 * 根据偏移量和内部节点最终的bounding box来得出该shape最终的bbox
 */
export declare function getBBox(node: NodeInstructure, offset: {
    x: number;
    y: number;
}, chilrenBBox: {
    width: number;
    height: number;
}): {
    x: number;
    y: number;
    width: number;
    height: number;
};
/**
 * 把从xml计算出的结构填上位置信息，补全attrs
 * @param target
 * @param lastOffset
 */
export declare function generateTarget(target: NodeInstructure, lastOffset?: {
    x: number;
    y: number;
}): NodeInstructure;
/**
 * 对比前后两个最终计算出来的node，并对比出最小改动,
 * 动作： 'add' 添加节点 ｜ ’delete‘ 删除节点 ｜ ’change‘ 改变节点attrs ｜ 'restructure' 重构节点
 * @param nowTarget
 * @param formerTarget
 */
export declare function compareTwoTarget(nowTarget: NodeInstructure, formerTarget: NodeInstructure): {
    action: string;
    val: NodeInstructure;
    type: string;
    key: any;
    nowTarget?: undefined;
    formerTarget?: undefined;
    children?: undefined;
} | {
    action: string;
    val: NodeInstructure;
    type: string;
    key?: undefined;
    nowTarget?: undefined;
    formerTarget?: undefined;
    children?: undefined;
} | {
    action: string;
    type: string;
    val?: undefined;
    key?: undefined;
    nowTarget?: undefined;
    formerTarget?: undefined;
    children?: undefined;
} | {
    action: string;
    nowTarget: NodeInstructure;
    formerTarget: NodeInstructure;
    key: any;
    children: any[];
    val?: undefined;
    type?: undefined;
} | {
    action: string;
    val: NodeInstructure;
    children: any[];
    type: string;
    key: any;
    nowTarget?: undefined;
    formerTarget?: undefined;
} | {
    action: string;
    children: any[];
    type: string;
    key: any;
    val?: undefined;
    nowTarget?: undefined;
    formerTarget?: undefined;
};
/**
 * 根据xml或者返回xml的函数构建自定义节点的结构
 * @param gen
 */
export declare function createNodeFromXML(gen: string | ((node: any) => string)): {
    draw(cfg: any, group: any): any;
    update(cfg: any, node: any): void;
    getAnchorPoints(): number[][];
};
export {};
