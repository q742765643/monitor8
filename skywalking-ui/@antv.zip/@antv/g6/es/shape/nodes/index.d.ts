import './circle';
import './rect';
import './ellipse';
import './diamond';
import './triangle';
import './modelRect';
import './star';
import './image';
