import { ShapeOptions } from '../interface/shape';
export declare const CLS_LABEL_BG_SUFFIX = "-label-bg";
export declare const shapeBase: ShapeOptions;
