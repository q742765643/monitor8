import { IPoint, Item } from '../../types';
/**
 * Use cross product to judge the direction of the turn.
 * Returns a positive value, if OAB makes a clockwise turn,
 * negative for counter-clockwise turn, and zero if the points are collinear.
 */
export declare const cross: (a: IPoint, b: IPoint, o: IPoint) => number;
/**
 * Generate a convex hull of given points. Andrew's monotone chain algorithm.
 * @param points An array of [x, y] representing the coordinates of points.
 * @return a list of vertices of the convex hull in counter-clockwise order,
 */
export declare const genConvexHull: (items: Item[]) => any[];
