import { Item, BubblesetCfg } from '../../types';
/**
 * Calculate the countor that includes the  selected items and exclues the non-selected items
 * @param graph
 * @param members
 * @param nonMembers
 * @param options
 */
export declare const genBubbleSet: (members: Item[], nonMembers: Item[], ops?: BubblesetCfg) => any[];
