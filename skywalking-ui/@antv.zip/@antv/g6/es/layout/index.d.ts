/**
 * @fileOverview layout entry file
 * @author shiwu.wyy@antfin.com
 */
import Layout from './layout';
export default Layout;
