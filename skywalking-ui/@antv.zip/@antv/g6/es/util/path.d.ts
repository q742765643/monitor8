import { IPoint } from '../types';
/**
 * 给定坐标获取三次贝塞尔曲线的 M 及 C 值
 * @param points coordinate set
 */
export declare const getSpline: (points: IPoint[]) => any[][];
/**
 * 根据起始点、相对位置、偏移量计算控制点
 * @param  {IPoint} startPoint 起始点，包含 x,y
 * @param  {IPoint} endPoint  结束点, 包含 x,y
 * @param  {Number} percent   相对位置,范围 0-1
 * @param  {Number} offset    偏移量
 * @return {IPoint} 控制点，包含 x,y
 */
export declare const getControlPoint: (startPoint: IPoint, endPoint: IPoint, percent?: number, offset?: number) => IPoint;
/**
 * 点集转化为Path多边形
 * @param {Array} points 点集
 * @param {Boolen} z 是否封闭
 * @return {Array} Path
 */
export declare const pointsToPolygon: (points: IPoint[], z?: boolean) => string;
export declare const pathToPoints: (path: any[]) => any[];
/**
 * 生成平滑的闭合曲线
 * @param points
 */
export declare const getClosedSpline: (points: IPoint[]) => any[];
/**
 * 传入的节点作为多边形顶点，生成有圆角的多边形
 * @param polyPoints 多边形顶点
 * @param padding 在原多边形基础上增加最终轮廓和原多边形的空白间隔
 */
export declare function roundedHull(polyPoints: number[][], padding: number): string;
/**
 * 传入的节点作为多边形顶点，生成平滑的闭合多边形
 * @param polyPoints
 * @param padding
 */
export declare function paddedHull(polyPoints: number[][], padding: number): string | {
    x: number;
    y: number;
}[];
