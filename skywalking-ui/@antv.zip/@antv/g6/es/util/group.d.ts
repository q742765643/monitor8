import { GraphData, GroupNodeIds } from '../types';
export declare const getAllNodeInGroups: (data: GraphData) => GroupNodeIds;
