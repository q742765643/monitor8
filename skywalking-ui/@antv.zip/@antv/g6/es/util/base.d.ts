import { G6GraphEvent } from '../interface/behavior';
import { IG6GraphEvent, Padding, Matrix, Item } from '../types';
/**
 * turn padding into [top, right, bottom, right]
 * @param  {Number|Array} padding input padding
 * @return {array} output
 */
export declare const formatPadding: (padding: Padding) => number[];
/**
 * clone event
 * @param e
 */
export declare const cloneEvent: (e: IG6GraphEvent) => G6GraphEvent;
/**
 * 判断 viewport 是否改变，通过和单位矩阵对比
 * @param matrix Viewport 的 Matrix
 */
export declare const isViewportChanged: (matrix: Matrix) => boolean;
export declare const isNaN: (input: any) => boolean;
/**
 * 计算一组 Item 的 BBox
 * @param items 选中的一组Item，可以是 node 或 combo
 */
export declare const calculationItemsBBox: (items: Item[]) => {
    x: number;
    y: number;
    width: number;
    height: number;
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
};
/**
 * 若 edges 中存在两端点相同的边，使用 quadratic 边并自动计算 curveOffset 使它们不相互重叠
 * @param edges 边数据集合
 * @param offsetDiff 相邻两边的 offset 之差
 */
export declare const processParallelEdges: (edges: any, offsetDiff?: number) => any;
