import { Point } from '@antv/g-base/lib/types';
import { IGroup } from '@antv/g-canvas/lib/interfaces';
import { GraphData, ICircle, IEllipse, IRect, Matrix, EdgeConfig, NodeIdxMap, IBBox, Item, IPoint } from '../types';
/**
 * 获取两条线段的交点
 * @param  {Point}  p0 第一条线段起点
 * @param  {Point}  p1 第一条线段终点
 * @param  {Point}  p2 第二条线段起点
 * @param  {Point}  p3 第二条线段终点
 * @return {Point}  交点
 */
export declare const getLineIntersect: (p0: Point, p1: Point, p2: Point, p3: Point) => Point | null;
/**
 * point and rectangular intersection point
 * @param  {IRect} rect  rect
 * @param  {Point} point point
 * @return {PointPoint} rst;
 */
export declare const getRectIntersectByPoint: (rect: IRect, point: Point) => Point | null;
/**
 * get point and circle inIntersect
 * @param {ICircle} circle 圆点，x,y,r
 * @param {Point} point 点 x,y
 * @return {Point} applied point
 */
export declare const getCircleIntersectByPoint: (circle: ICircle, point: Point) => Point | null;
/**
 * get point and ellipse inIntersect
 * @param {Object} ellipse 椭圆 x,y,rx,ry
 * @param {Object} point 点 x,y
 * @return {object} applied point
 */
export declare const getEllipseIntersectByPoint: (ellipse: IEllipse, point: Point) => Point;
/**
 * coordinate matrix transformation
 * @param  {number} point   coordinate
 * @param  {Matrix} matrix  matrix
 * @param  {number} tag     could be 0 or 1
 * @return {Point} transformed point
 */
export declare const applyMatrix: (point: Point, matrix: Matrix, tag?: 0 | 1) => Point;
/**
 * coordinate matrix invert transformation
 * @param  {number} point   coordinate
 * @param  {number} matrix  matrix
 * @param  {number} tag     could be 0 or 1
 * @return {object} transformed point
 */
export declare const invertMatrix: (point: Point, matrix: Matrix, tag?: 0 | 1) => Point;
/**
 *
 * @param p1 First coordinate
 * @param p2 second coordinate
 * @param p3 three coordinate
 */
export declare const getCircleCenterByPoints: (p1: Point, p2: Point, p3: Point) => Point;
/**
 * get distance by two points
 * @param p1 first point
 * @param p2 second point
 */
export declare const distance: (p1: Point, p2: Point) => number;
/**
 * scale matrix
 * @param matrix [ [], [], [] ]
 * @param ratio
 */
export declare const scaleMatrix: (matrix: Matrix[], ratio: number) => Matrix[];
/**
 * Floyd Warshall algorithm for shortest path distances matrix
 * @param  {array} adjMatrix   adjacency matrix
 * @return {array} distances   shortest path distances matrix
 */
export declare const floydWarshall: (adjMatrix: Matrix[]) => Matrix[];
/**
 * get adjacency matrix
 * @param data graph data
 * @param directed whether it's a directed graph
 */
export declare const getAdjMatrix: (data: GraphData, directed: boolean) => Matrix[];
/**
 * 平移group
 * @param group Group 实例
 * @param vec 移动向量
 */
export declare const translate: (group: IGroup, vec: Point) => void;
/**
 * 移动到指定坐标点
 * @param group Group 实例
 * @param point 移动到的坐标点
 */
export declare const move: (group: IGroup, point: Point) => void;
/**
 * 缩放 group
 * @param group Group 实例
 * @param point 在x 和 y 方向上的缩放比例
 */
export declare const scale: (group: IGroup, ratio: number | number[]) => void;
/**
 *
 * @param group Group 实例
 * @param ratio 选择角度
 */
export declare const rotate: (group: IGroup, angle: number) => void;
export declare const getDegree: (n: number, nodeIdxMap: NodeIdxMap, edges: EdgeConfig[]) => number[];
/**
 * 判断点P在多边形内-射线法. Borrow from https://github.com/antvis/util/blob/master/packages/path-util/src/point-in-polygon.ts
 * @param points
 * @param x
 * @param y
 */
export declare const isPointInPolygon: (points: number[][], x: number, y: number) => boolean;
export declare const intersectBBox: (box1: Partial<IBBox>, box2: Partial<IBBox>) => boolean;
/**
 * 判断两个polygon是否相交。
 * borrow from @antv/path-util
 * @param points1 polygon1的顶点数组
 * @param points2 polygon2的顶点数组
 */
export declare const isPolygonsIntersect: (points1: number[][], points2: number[][]) => boolean;
export declare class Line {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    constructor(x1: number, y1: number, x2: number, y2: number);
    getBBox(): {
        x: number;
        y: number;
        minX: number;
        minY: number;
        maxX: number;
        maxY: number;
        width: number;
        height: number;
    };
}
export declare const getBBoxBoundLine: (bbox: IBBox, direction: string) => any;
export declare const itemIntersectByLine: (item: Item, line: Line) => [IPoint[], number];
export declare const fractionToLine: (item: Item, line: Line) => number;
export declare const getPointsCenter: (points: IPoint[]) => IPoint;
export declare const squareDist: (a: IPoint, b: IPoint) => number;
export declare const pointLineSquareDist: (point: IPoint, line: Line) => number;
export declare const isPointsOverlap: (p1: any, p2: any, e?: number) => boolean;
/**
 * 点到矩形的距离的平方：矩形内部点视作距离为0，外部的点若投影落在矩形边上则为点到矩形边的最近的垂直距离，否则为点到矩形顶点的距离，
 * @param point IPoint
 * @param rect IRect
 */
export declare const pointRectSquareDist: (point: Point, rect: IRect) => number;
