import { IGroup } from '@antv/g-base';
import { Item, BubblesetCfg, HullCfg } from '../types';
import { IGraph } from '../interface/graph';
/**
 * 用于包裹内部的成员的轮廓。
 * convex hull(凸包)：http://geomalgorithms.com/a10-_hull-1.html#Monotone%20Chain
 * bubble: 使用 bubbleset算法，refer: http://vialab.science.uoit.ca/wp-content/papercite-data/pdf/col2009c.pdf
 * 通过配置 padding 可以调节包裹轮廓对节点的松紧程度
 */
export default class Hull {
    id: string;
    graph: IGraph;
    cfg: any;
    path: any[][];
    group: IGroup;
    members: Item[];
    nonMembers: Item[];
    padding: number;
    bubbleCfg: Partial<BubblesetCfg>;
    type: string;
    constructor(graph: IGraph, cfg: HullCfg);
    getDefaultCfg(): HullCfg;
    setPadding(): void;
    setType(): void;
    calcPath(members: Item[], nonMembers: Item[]): any;
    render(): void;
    /**
     * 增加hull的成员，同时如果该成员原先在nonMembers中，则从nonMembers中去掉
     * @param item 节点实例
     * @return boolean 添加成功返回 true，否则返回 false
     */
    addMember(item: Item | string): boolean;
    /**
     * 增加hull需要排除的节点，同时如果该成员原先在members中，则从members中去掉
     * @param item 节点实例
     * @return boolean 添加成功返回 true，否则返回 false
     */
    addNonMember(item: Item | string): boolean;
    /**
     * 移除hull中的成员
     * @param node 节点实例
     * @return boolean 移除成功返回 true，否则返回 false
     */
    removeMember(item: Item | string): boolean;
    /**
     * @param node 节点实例
     * @return boolean 移除成功返回 true，否则返回 false
     */
    removeNonMember(item: Item | string): boolean;
    updateData(members: Item[] | string[], nonMembers: string[] | Item[]): void;
    updateStyle(cfg: HullCfg['style']): void;
    updateCfg(cfg: Partial<HullCfg>): void;
    /**
     * 判断是否在hull内部
     * @param item
     */
    contain(item: Item | string): boolean;
    destroy(): void;
}
