import Behaviors from './behavior';
import Graph from './graph/graph';
import TreeGraph from './graph/tree-graph';
import Shape from './shape';
import Layout from './layout';
import Global from './global';
import Util from './util';
import * as Algorithm from './algorithm';
declare const registerNode: typeof Shape.registerNode;
declare const registerEdge: typeof Shape.registerEdge;
declare const registerCombo: typeof Shape.registerCombo;
declare const registerBehavior: typeof Behaviors.registerBehavior;
declare const registerLayout: <Cfg>(type: string, layout: Partial<import("./interface/layout").ILayout<Cfg>>, layoutCons?: new () => import("./layout/layout").BaseLayout<Cfg>) => void;
declare const Minimap: typeof import("./plugins/minimap").default;
declare const Grid: typeof import("./plugins/grid").default;
declare const Bundling: typeof import("./plugins/bundling").default;
declare const Menu: typeof import("./plugins/menu").default;
declare const Fisheye: typeof import("./plugins/fisheye").default;
declare const ToolBar: typeof import("./plugins/toolBar").default;
declare const Tooltip: typeof import("./plugins/tooltip").default;
declare const TimeBar: typeof import("./plugins/timeBar").default;
declare const ImageMinimap: typeof import("./plugins/imageMinimap").default;
export { registerNode, registerCombo, Graph, TreeGraph, Util, registerEdge, Layout, Global, registerLayout, Minimap, Grid, Bundling, Menu, Fisheye, registerBehavior, Algorithm, ToolBar, Tooltip, TimeBar, ImageMinimap, };
declare const _default: {
    version: string;
    Graph: typeof Graph;
    TreeGraph: typeof TreeGraph;
    Util: {
        getLineIntersect: (p0: import("@antv/g-base").Point, p1: import("@antv/g-base").Point, p2: import("@antv/g-base").Point, p3: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        getRectIntersectByPoint: (rect: import("./types").IRect, point: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        getCircleIntersectByPoint: (circle: import("./types").ICircle, point: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        getEllipseIntersectByPoint: (ellipse: import("./types").IEllipse, point: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        applyMatrix: (point: import("@antv/g-base").Point, matrix: import("./types").Matrix, tag?: 0 | 1) => import("@antv/g-base").Point;
        invertMatrix: (point: import("@antv/g-base").Point, matrix: import("./types").Matrix, tag?: 0 | 1) => import("@antv/g-base").Point;
        getCircleCenterByPoints: (p1: import("@antv/g-base").Point, p2: import("@antv/g-base").Point, p3: import("@antv/g-base").Point) => import("@antv/g-base").Point;
        distance: (p1: import("@antv/g-base").Point, p2: import("@antv/g-base").Point) => number;
        scaleMatrix: (matrix: import("./types").Matrix[], ratio: number) => import("./types").Matrix[];
        floydWarshall: (adjMatrix: import("./types").Matrix[]) => import("./types").Matrix[];
        getAdjMatrix: (data: import("./types").GraphData, directed: boolean) => import("./types").Matrix[];
        translate: (group: import("@antv/g-base").IGroup, vec: import("@antv/g-base").Point) => void;
        move: (group: import("@antv/g-base").IGroup, point: import("@antv/g-base").Point) => void;
        scale: (group: import("@antv/g-base").IGroup, ratio: number | number[]) => void;
        rotate: (group: import("@antv/g-base").IGroup, angle: number) => void;
        getDegree: (n: number, nodeIdxMap: import("./types").NodeIdxMap, edges: import("./types").EdgeConfig[]) => number[];
        isPointInPolygon: (points: number[][], x: number, y: number) => boolean;
        intersectBBox: (box1: Partial<import("./types").IBBox>, box2: Partial<import("./types").IBBox>) => boolean;
        isPolygonsIntersect: (points1: number[][], points2: number[][]) => boolean;
        Line: typeof import("./util/math").Line;
        getBBoxBoundLine: (bbox: import("./types").IBBox, direction: string) => any;
        itemIntersectByLine: (item: import("./types").Item, line: import("./util/math").Line) => [import("./types").IPoint[], number];
        fractionToLine: (item: import("./types").Item, line: import("./util/math").Line) => number;
        getPointsCenter: (points: import("./types").IPoint[]) => import("./types").IPoint;
        squareDist: (a: import("./types").IPoint, b: import("./types").IPoint) => number;
        pointLineSquareDist: (point: import("./types").IPoint, line: import("./util/math").Line) => number;
        isPointsOverlap: (p1: any, p2: any, e?: number) => boolean;
        pointRectSquareDist: (point: import("@antv/g-base").Point, rect: import("./types").IRect) => number;
        roundedHull(polyPoints: number[][], padding: number): string;
        paddedHull(polyPoints: number[][], padding: number): string | {
            x: number;
            y: number;
        }[];
        getSpline: (points: import("./types").IPoint[]) => any[][];
        getControlPoint: (startPoint: import("./types").IPoint, endPoint: import("./types").IPoint, percent?: number, offset?: number) => import("./types").IPoint;
        pointsToPolygon: (points: import("./types").IPoint[], z?: boolean) => string;
        pathToPoints: (path: any[]) => any[];
        getClosedSpline: (points: import("./types").IPoint[]) => any[];
        getBBox: (element: import("./types").IShapeBase, group: import("@antv/g-canvas/lib/group").default) => import("./types").IBBox;
        getLoopCfgs: (cfg: import("./types").EdgeData) => import("./types").EdgeData;
        getLabelPosition: (pathShape: import("@antv/g-canvas/lib/shape/path").default, percent: number, refX: number, refY: number, rotate: boolean) => Partial<{
            rotate: number;
            textAlign: string;
            angle: number;
            x: number;
            y: number;
            text: string;
            stroke: string;
            opacity: number;
            fontSize: number;
            fontStyle: string;
            fill: string;
            rotateCenter: string;
            lineWidth?: number;
            shadowColor?: string;
            shadowBlur?: number;
            shadowOffsetX?: number;
            shadowOffsetY?: number;
            position: string;
            textBaseline: string;
            offset: number;
            background?: {
                fill?: string;
                stroke?: string;
                lineWidth?: number;
                radius?: number | number[];
                padding?: number | number[];
            };
        }>;
        traverseTree: <T extends {
            children?: T[];
        }>(data: T, fn: (param: T) => boolean) => void;
        traverseTreeUp: <T_1 extends {
            children?: T_1[];
        }>(data: T_1, fn: (param: T_1) => boolean) => void;
        radialLayout: (data: import("./util/graphic").TreeGraphDataWithPosition, layout?: string) => import("./util/graphic").TreeGraphDataWithPosition;
        getLetterWidth: (letter: any, fontSize: any) => number;
        getTextSize: (text: any, fontSize: any) => any[];
        plainCombosToTrees: (array: import("./types").ComboConfig[], nodes?: import("./types").NodeConfig[]) => import("./types").ComboTree[];
        reconstructTree: (trees: import("./types").ComboTree[], subtreeId?: string, newParentId?: string) => import("./types").ComboTree[];
        getComboBBox: (children: import("./types").ComboTree[], graph: import("./interface/graph").IGraph) => import("@antv/g-math/lib/types").BBox;
        getChartRegion: (params: {
            group: import("@antv/g-canvas/lib/group").default;
            width: number;
            height: number;
            x: number;
            y: number;
        }) => {
            start: {
                x: number;
                y: number;
            };
            end: {
                x: number;
                y: number;
            };
        };
        formatPadding: (padding: import("./types").Padding) => number[];
        cloneEvent: (e: import("./types").IG6GraphEvent) => import("./interface/behavior").G6GraphEvent;
        isViewportChanged: (matrix: import("./types").Matrix) => boolean;
        isNaN: (input: any) => boolean;
        calculationItemsBBox: (items: import("./types").Item[]) => {
            x: number;
            y: number;
            width: number;
            height: number;
            minX: number;
            minY: number;
            maxX: number;
            maxY: number;
        };
        processParallelEdges: (edges: any, offsetDiff?: number) => any;
        mat3: any;
        mix: typeof import("@antv/util").mix;
        deepMix: (rst: any, ...args: any[]) => any;
        transform: (m: any, ts: any) => any;
    };
    registerNode: typeof Shape.registerNode;
    registerEdge: typeof Shape.registerEdge;
    registerCombo: typeof Shape.registerCombo;
    registerBehavior: typeof Behaviors.registerBehavior;
    registerLayout: <Cfg>(type: string, layout: Partial<import("./interface/layout").ILayout<Cfg>>, layoutCons?: new () => import("./layout/layout").BaseLayout<Cfg>) => void;
    Layout: {
        [layoutType: string]: any;
        registerLayout<Cfg>(type: string, layout: Partial<import("./interface/layout").ILayout<Cfg>>, layoutCons?: new () => import("./layout/layout").BaseLayout<Cfg>): void;
    };
    Global: {
        version: string;
        rootContainerClassName: string;
        nodeContainerClassName: string;
        edgeContainerClassName: string;
        comboContainerClassName: string;
        customGroupContainerClassName: string;
        delegateContainerClassName: string;
        defaultShapeFillColor: string;
        defaultShapeStrokeColor: string;
        defaultLoopPosition: string;
        nodeLabel: {
            style: {
                fill: string;
                textAlign: string;
                textBaseline: string;
            };
            offset: number;
        };
        defaultNode: {
            type: string;
            style: {
                fill: string;
                lineWidth: number;
                stroke: string;
            };
            size: number;
            color: string;
        };
        edgeLabel: {
            style: {
                fill: string;
                textAlign: string;
                textBaseline: string;
            };
        };
        defaultEdge: {
            type: string;
            style: {
                stroke: string;
            };
            size: number;
            color: string;
        };
        comboLabel: {
            style: {
                fill: string;
                textBaseline: string;
            };
            refY: number;
            refX: number;
        };
        defaultCombo: {
            type: string;
            style: {
                fill: string;
                lineWidth: number;
                stroke: string;
                opacity: number;
                r: number;
                width: number;
                height: number;
            };
            size: number[];
            color: string;
            padding: number[];
        };
        nodeStateStyle: {};
        delegateStyle: {
            fill: string;
            fillOpacity: number;
            stroke: string;
            strokeOpacity: number;
            lineDash: number[];
        };
    };
    Minimap: typeof import("./plugins/minimap").default;
    Grid: typeof import("./plugins/grid").default;
    Bundling: typeof import("./plugins/bundling").default;
    Menu: typeof import("./plugins/menu").default;
    ToolBar: typeof import("./plugins/toolBar").default;
    Tooltip: typeof import("./plugins/tooltip").default;
    TimeBar: typeof import("./plugins/timeBar").default;
    Fisheye: typeof import("./plugins/fisheye").default;
    ImageMinimap: typeof import("./plugins/imageMinimap").default;
    Algorithm: typeof Algorithm;
    Arrow: {
        triangle: (width?: number, length?: number, d?: number) => string;
        vee: (width?: number, length?: number, d?: number) => string;
        circle: (r?: number, d?: number) => string;
        rect: (width?: number, length?: number, d?: number) => string;
        diamond: (width?: number, length?: number, d?: number) => string;
        triangleRect: (tWidth?: number, tLength?: number, rWidth?: number, rLength?: number, gap?: number, d?: number) => string;
    };
    Marker: {
        collapse: (x: any, y: any, r: any) => any[][];
        expand: (x: any, y: any, r: any) => any[][];
        upTriangle: (x: any, y: any, r: any) => any[][];
        downTriangle: (x: any, y: any, r: any) => any[][];
    };
};
export default _default;
