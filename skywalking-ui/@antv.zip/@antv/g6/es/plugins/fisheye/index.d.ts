import { IG6GraphEvent, ShapeStyle } from '../../types';
import Base from '../base';
interface FisheyeConfig {
    trigger?: 'mousemove' | 'click' | 'drag';
    d?: number;
    r?: number;
    delegateStyle?: ShapeStyle;
    showLabel?: boolean;
    scaleRBy?: 'wheel' | 'drag' | 'unset' | undefined;
    scaleDBy?: 'wheel' | 'drag' | 'unset' | undefined;
    maxR?: number;
    minR?: number;
    maxD?: number;
    minD?: number;
    showDPercent?: boolean;
}
export default class Fisheye extends Base {
    getDefaultCfgs(): FisheyeConfig;
    getEvents(): any;
    init(): void;
    protected createDelegate(e: IG6GraphEvent): void;
    /**
     * 滚轮调整放大镜范围
     * @param e wheel 事件
     */
    protected scaleRByWheel(e: IG6GraphEvent): void;
    /**
     * 拖拽 lens 调整范围
     * @param e wheel 事件
     */
    protected scaleRByDrag(e: IG6GraphEvent): void;
    /**
     * 滚轮调整放大镜缩放系数 d
     * @param e wheel 事件
     */
    protected scaleDByWheel(evt: IG6GraphEvent): void;
    /**
     * 拖拽 lens 调整缩放系数 d
     * @param e wheel 事件
     */
    protected scaleDByDrag(e: IG6GraphEvent): void;
    /**
     * mousemove、click、drag 事件的响应函数
     * @param e 鼠标事件
     */
    protected magnify(e: IG6GraphEvent, mousePos?: any): void;
    /**
     * 恢复缓存的被缩放的节点
     */
    protected restoreCache(): void;
    /**
     * 提供给用户调整系数
     * @param {Point} mCenter
     * @param {number} r
     */
    updateParams(cfg: FisheyeConfig): void;
    /**
     * 放大镜的图形
     * @param {Point} mCenter
     * @param {number} r
     */
    private updateDelegate;
    clear(): void;
    destroy(): void;
}
export {};
