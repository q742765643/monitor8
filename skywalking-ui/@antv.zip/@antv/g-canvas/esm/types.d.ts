export * from '@antv/g-base/lib/types';
export declare type Region = {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
};
