export default function inPolyline(points: any[], lineWidth: number, x: number, y: number, isClose: boolean): boolean;
