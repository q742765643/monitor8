export default function inLine(x1: any, y1: any, x2: any, y2: any, lineWidth: any, x: any, y: any): boolean;
