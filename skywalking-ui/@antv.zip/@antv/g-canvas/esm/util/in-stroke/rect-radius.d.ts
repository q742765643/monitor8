export default function rectWithRadius(minX: any, minY: any, width: any, height: any, radius: any, lineWidth: any, x: any, y: any): boolean;
