export default function arc(cx: any, cy: any, r: any, startAngle: any, endAngle: any, lineWidth: any, x: any, y: any): boolean;
