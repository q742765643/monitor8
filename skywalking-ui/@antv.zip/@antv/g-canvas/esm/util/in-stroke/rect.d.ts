export default function inRect(minX: any, minY: any, width: any, height: any, lineWidth: any, x: any, y: any): boolean;
