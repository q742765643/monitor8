import { IContainer } from '@antv/g-base/lib/interfaces';
export declare function getShape(container: IContainer, x: number, y: number): any;
