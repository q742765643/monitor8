export default function getArcParams(startPoint: any, params: any): {
    cx: number;
    cy: number;
    rx: any;
    ry: any;
    startAngle: number;
    endAngle: number;
    xRotation: number;
    arcFlag: any;
    sweepFlag: any;
};
