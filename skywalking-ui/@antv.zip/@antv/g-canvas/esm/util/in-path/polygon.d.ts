/**
 * @fileoverview 判断点是否在多边形内
 * @author dxq613@gmail.com
 */
export default function isInPolygon(points: any, x: any, y: any): boolean;
