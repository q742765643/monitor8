export default function isPointInPath(shape: any, x: any, y: any): any;
