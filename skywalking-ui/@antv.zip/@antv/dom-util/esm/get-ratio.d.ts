export default function getRatio(): number;
