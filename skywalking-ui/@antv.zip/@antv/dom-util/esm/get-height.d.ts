export default function getHeight(el: HTMLElement, defaultValue?: any): number;
