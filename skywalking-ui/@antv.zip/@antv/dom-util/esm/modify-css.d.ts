export default function modifyCSS(dom: HTMLElement, css: {
    [key: string]: any;
}): HTMLElement;
