export default function getOuterHeight(el: HTMLElement, defaultValue?: any): number;
