export default function addEventListener(target: HTMLElement, eventType: string, callback: any): {
    remove(): void;
};
