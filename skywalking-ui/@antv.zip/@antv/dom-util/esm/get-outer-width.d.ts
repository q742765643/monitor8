export default function getOuterWidth(el: HTMLElement, defaultValue?: any): number;
