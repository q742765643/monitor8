export declare const isColorProp: (prop: any) => boolean;
export declare const isGradientColor: (val: any) => boolean;
