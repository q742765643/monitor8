export declare function getOffScreenContext(): any;
