import { getMethod } from './register';
export { getMethod as getBBoxMethod };
