import { IShape } from '../interfaces';
export declare function mergeBBox(bbox1: any, bbox2: any): any;
export declare function mergeArrowBBox(shape: IShape, bbox: any): any;
