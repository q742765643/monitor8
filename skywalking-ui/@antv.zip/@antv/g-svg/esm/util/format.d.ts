export declare function parseRadius(radius: any): {
    r1: number;
    r2: number;
    r3: number;
    r4: number;
};
export declare function parsePath(path: any): any;
