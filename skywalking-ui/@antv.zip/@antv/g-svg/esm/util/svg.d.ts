export declare function setShadow(model: any, context: any): void;
export declare function setTransform(model: any): void;
export declare function setClip(model: any, context: any): void;
