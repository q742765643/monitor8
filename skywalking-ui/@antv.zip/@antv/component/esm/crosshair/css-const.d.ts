export declare const CONTAINER_CLASS = "g2-crosshair";
export declare const CROSSHAIR_LINE: string;
export declare const CROSSHAIR_TEXT: string;
