declare const _default: {
    [x: string]: {
        position: string;
        backgroundColor?: undefined;
        color?: undefined;
        fontFamily?: undefined;
    } | {
        position: string;
        backgroundColor: string;
        color?: undefined;
        fontFamily?: undefined;
    } | {
        position: string;
        color: string;
        fontFamily: string;
        backgroundColor?: undefined;
    };
};
export default _default;
