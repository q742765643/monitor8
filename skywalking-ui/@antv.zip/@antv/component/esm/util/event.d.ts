import { IGroup } from '@antv/g-base';
import { LooseObject } from '../types';
/**
 *
 * @param group 分组
 * @param eventName 事件名
 * @param eventObject 事件对象
 */
export declare function propagationDelegate(group: IGroup, eventName: string, eventObject: LooseObject): void;
