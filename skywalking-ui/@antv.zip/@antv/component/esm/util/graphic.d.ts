import { IGroup } from '@antv/g-base';
import { EnhancedTextCfg } from '../types';
export interface TagCfg extends EnhancedTextCfg {
    /** 组件的 id 标识 */
    id?: string;
    /** 组件的名字 */
    name?: string;
    /**
     * 文本标注位置 x
     */
    x: number;
    /**
     * 文本标注位置 y
     */
    y: number;
}
export declare function renderTag(container: IGroup, tagCfg: TagCfg): void;
