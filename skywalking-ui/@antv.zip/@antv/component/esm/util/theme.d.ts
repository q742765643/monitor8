declare const _default: {
    fontFamily: string;
    textColor: string;
    activeTextColor: string;
    uncheckedColor: string;
    lineColor: string;
    regionColor: string;
    verticalAxisRotate: number;
    horizontalAxisRotate: number;
};
export default _default;
