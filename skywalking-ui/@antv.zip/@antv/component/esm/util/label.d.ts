import { IElement } from '@antv/g-base';
/** 获取最长的 label */
export declare function getMaxLabelWidth(labels: IElement[]): number;
/** 获取label长度 */
export declare function getLabelLength(isVertical: boolean, label: any): any;
export declare function testLabel(label: IElement, limitLength: number): boolean;
/** 处理 text shape 的自动省略 */
export declare function ellipsisLabel(isVertical: boolean, label: IElement, limitLength: number, position?: string): boolean;
