import { ListItem } from '../types';
export declare function getStatesStyle(item: ListItem, elementName: string, stateStyles: object): any;
