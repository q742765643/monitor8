/** 获取字符串长度 */
export declare function strLen(str: string): number;
/** 是否属于ASCII编码范畴 */
export declare function charAtLength(str: string, i: number): 1 | 2;
/** 文本省略 */
export declare function ellipsisString(str: string, reseveLength: number, position?: string): string;
