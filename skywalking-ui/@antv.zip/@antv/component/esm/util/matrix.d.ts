import { IElement } from '@antv/g-base';
import { BBox, Point } from '../types';
export declare function getMatrixByAngle(point: Point, angle: number, matrix?: number[]): number[];
export declare function getMatrixByTranslate(point: Point, currentMatrix?: number[]): number[];
export declare function getAngleByMatrix(matrix: [number, number, number, number, number, number, number, number, number]): number;
export declare function applyMatrix2BBox(matrix: number[], bbox: BBox): {
    x: number;
    y: number;
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    width: number;
    height: number;
};
export declare function applyRotate(shape: IElement, rotate: number, x: number, y: number): void;
export declare function applyTranslate(shape: IElement, x: number, y: number): void;
