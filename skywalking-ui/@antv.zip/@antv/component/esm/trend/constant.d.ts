export declare const BACKGROUND_STYLE: {
    opacity: number;
};
export declare const LINE_STYLE: {
    stroke: string;
    strokeOpacity: number;
};
export declare const AREA_STYLE: {
    fill: string;
    opacity: number;
};
