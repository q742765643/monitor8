import { IGroup } from '@antv/g-base';
export declare function getDefault(): typeof equidistance;
/**
 * 保证首个 label 可见，即使超过 limitLength 也不隐藏
 * @param {boolean} isVertical  是否垂直
 * @param {IGroup}  labelsGroup label 的分组
 */
export declare function reserveFirst(isVertical: boolean, labelsGroup: IGroup): boolean;
/**
 * 保证最后一个 label 可见，即使超过 limitLength 也不隐藏
 * @param {boolean} isVertical  是否垂直
 * @param {IGroup}  labelsGroup label 的分组
 */
export declare function reserveLast(isVertical: boolean, labelsGroup: IGroup): boolean;
/**
 * 保证第一个最后一个 label 可见，即使超过 limitLength 也不隐藏
 * @param {boolean} isVertical  是否垂直
 * @param {IGroup}  labelsGroup label 的分组
 */
export declare function reserveBoth(isVertical: boolean, labelsGroup: IGroup): boolean;
/**
 * 保证 label 均匀显示，主要解决文本层叠的问题，对于 limitLength 不处理
 * @param {boolean} isVertical  是否垂直
 * @param {IGroup}  labelsGroup label 的分组
 */
export declare function equidistance(isVertical: boolean, labelsGroup: IGroup): boolean;
