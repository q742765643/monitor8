import { IGroup } from '@antv/g-base';
export declare function wrapLabels(labelGroup: IGroup, limitLength: number): boolean;
