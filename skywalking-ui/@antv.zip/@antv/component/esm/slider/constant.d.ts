/**
 * 一些默认的样式配置
 */
export declare const BACKGROUND_STYLE: {
    fill: string;
    opacity: number;
};
export declare const FOREGROUND_STYLE: {
    fill: string;
    opacity: number;
    cursor: string;
};
export declare const DEFAULT_HANDLER_WIDTH = 10;
export declare const HANDLER_STYLE: {
    width: number;
    height: number;
};
export declare const TEXT_STYLE: {
    textBaseline: string;
    fill: string;
    opacity: number;
};
export declare const SLIDER_CHANGE = "sliderchange";
