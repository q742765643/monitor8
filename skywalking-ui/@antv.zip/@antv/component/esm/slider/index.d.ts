export { Slider, SliderCfg, TrendCfg } from './slider';
