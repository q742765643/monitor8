declare const _default: {
    rgb2arr: (str: string) => number[];
    gradient: (colors: string | string[]) => (percent: number) => string;
    toRGB: {
        (...args: any[]): any;
        cache: Map<any, any>;
    };
    toCSSGradient: (gradientColor: any) => any;
};
export default _default;
